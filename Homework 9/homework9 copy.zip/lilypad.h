#ifndef LILYPAD_BITMAP_H
#define LILYPAD_BITMAP_H
extern const unsigned short lilypad[14400];
#define LILYPAD_WIDTH 120
#define LILYPAD_HEIGHT 120
#endif